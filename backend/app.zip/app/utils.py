from functools import wraps
from flask import session, abort, request, current_app, g
import jwt

def roles_required(*allowed_roles):
    """
    Decorator untuk membatasi akses view berdasarkan role.
    """
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            if session.get('role') not in allowed_roles:
                abort(403)
            return f(*args, **kwargs)
        return wrapped
    return decorator

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if 'username' not in session:
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return wrapper

def jwt_roles_required(*allowed_roles):
    from functools import wraps
    from flask import g
    def wrapper(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if not hasattr(g, 'role'):
                return {'message': 'Unauthorized'}, 401
            if g.role not in allowed_roles:
                return {'message': 'Forbidden'}, 403
            return f(*args, **kwargs)
        return decorated
    return wrapper

def jwt_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.headers.get('Authorization', None)
        if not auth or not auth.startswith('Bearer '):
            return {'message': 'Missing or invalid token'}, 401

        token = auth.split(' ')[1]
        try:
            payload = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=['HS256'])
            g.user_id = payload.get('sub')
            g.username = payload.get('username')
            g.role = payload.get('role')
        except jwt.ExpiredSignatureError:
            return {'message': 'Token expired'}, 401
        except jwt.InvalidTokenError:
            return {'message': 'Invalid token'}, 401

        return f(*args, **kwargs)
    return decorated
from ..database import get_db_connection
import datetime, json
from psycopg2.extras import RealDictCursor

ENUM_MAP = {
  'transaction':'anomaly transaction',
  'wallet':'suspicious wallet'
}

def list_cases(limit: int = 50) -> list:
    """Get daftar case terbaru, lengkap dengan assignments."""
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute("""
        SELECT c.*, 
               COALESCE(json_agg(
                   json_build_object(
                       'user_id', ca.user_id,
                       'assigned_at', ca.assigned_at
                   ) 
               ) FILTER (WHERE ca.user_id IS NOT NULL), '[]') AS assignments
        FROM cases c
        LEFT JOIN case_assignments ca ON ca.case_id = c.id
        GROUP BY c.id
        ORDER BY c.created_at DESC
        LIMIT %s
    """, (limit,))
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return rows

def assign_case(case_id: int, user_id: int):
    """Assign case ke user tertentu."""
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM case_assignments WHERE case_id = %s", (case_id,))
    cur.execute("""
        INSERT INTO case_assignments (case_id, user_id, assigned_at)
        VALUES (%s, %s, NOW())
    """, (case_id, user_id))
    conn.commit()
    cur.close()
    conn.close()
    
def create_case(case_type: str, reference_id: str, payload: dict = None) -> int:
    """Insert case baru, kembalikan ID-nya."""
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT id FROM cases WHERE reference_id = %s", (reference_id,))
    existing = cur.fetchone()
    if existing:
        raise Exception("Case already exists")
    db_type = ENUM_MAP.get(case_type)
    if not db_type:
        raise ValueError(f"Unsupported case_type: {case_type}")
    
    cur.execute("""
        INSERT INTO cases (case_type, reference_id, payload, status, created_at, updated_at)
        VALUES (%s, %s, %s, %s, %s, %s)
        RETURNING id
    """, (
        db_type,
        reference_id,
        json.dumps(payload) if payload else None,
        'Alert',
        datetime.datetime.utcnow(),
        datetime.datetime.utcnow()
    ))
    case_id = cur.fetchone()[0]
    conn.commit()
    cur.close(); conn.close()
    return case_id

def update_case(case_id, data: dict):
    allowed_fields = ['description', 'status', 'reason', 'source', 'tags']
    updates = {}
    values = []

    for field in allowed_fields:
        if field in data:
            updates[field] = data[field]

    if not updates:
        raise ValueError("No valid fields to update")

    set_clauses = []
    for field in updates:
        set_clauses.append(f"{field} = %s")
        values.append(updates[field])

    values.append(case_id)

    sql = f"""
        UPDATE cases
        SET {', '.join(set_clauses)},
            updated_at = NOW()
        WHERE id = %s
    """

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(sql, values)
    conn.commit()
    cur.close()
    conn.close()
    
def can_user_see_case(case, user):
    if user['role'] == 'admin':
        return True
    if 'assignments' not in case:
        return False

    # Ambil role dari user yang ditugaskan
    assigned_roles = [a['role'] for a in case['assignments'] if 'role' in a]

    return user['role'] in assigned_roles

def get_case_with_assignments(case_id: int):
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute("""
        SELECT c.*, 
               json_agg(json_build_object(
                  'user_id', ca.user_id,
                  'assigned_at', ca.assigned_at
               )) AS assignments
        FROM cases c
        LEFT JOIN case_assignments ca ON ca.case_id = c.id
        WHERE c.id = %s
        GROUP BY c.id
    """, (case_id,))
    row = cur.fetchone()
    cur.close(); conn.close()
    return row

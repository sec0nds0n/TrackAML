import os
from flask import Flask, render_template
from dotenv import load_dotenv
from flask_cors import CORS
from .config import Config
from .extensions import flask_session_ext, neo4j_driver
from .auth.routes import auth_bp
from .aml.routes import aml_bp
from app.api.routes import api_bp
from app.users.routes import users_bp
from .services.scheduler import run_all_detectors

def create_app():
    load_dotenv()
    app = Flask(__name__, static_folder="static", template_folder="templates")
    app.secret_key = os.environ.get('SECRET_KEY', 'dev-secret')
    app.config.from_object('app.config.Config')
    CORS(app)

    # JWT Middleware harus di sini
    from flask import request, g
    import jwt

    @app.before_request
    def load_jwt_user():
        auth = request.headers.get('Authorization', '')
        if auth.startswith('Bearer '):
            token = auth.split()[1]
            try:
                data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
                g.user_id = data.get('sub')
                g.role = data.get('role')
                g.username = data.get('username')
            except jwt.ExpiredSignatureError:
                g.user_id = None
            except jwt.InvalidTokenError:
                g.user_id = None
        else:
            g.user_id = None

    # Routes
    from flask import session, redirect, url_for
    @app.route('/')
    def home():
        if 'username' in session:
            return redirect(url_for('aml.wallet'))
        return redirect(url_for('auth.login'))

    # Extensions
    flask_session_ext.init_app(app)
    neo4j_driver.init_app(app)

    # Blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(aml_bp)
    app.register_blueprint(api_bp)
    app.register_blueprint(users_bp)

    return app
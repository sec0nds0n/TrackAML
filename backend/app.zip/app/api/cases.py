from flask_restx import Namespace, Resource, fields
from flask import request, session
from ..utils import jwt_required, jwt_roles_required, roles_required, login_required
from ..services.case_service import list_cases, assign_case, create_case, update_case, get_case_with_assignments
from flask import g

api = Namespace('cases', description='Manage AML cases')

# Model untuk response sebuah case
assignment_model = api.model('Assignment', {
  'user_id': fields.Integer,
  'assigned_at': fields.DateTime
})
case_model = api.model('Case', {
  'id': fields.Integer,
  'case_type': fields.String,
  'reference_id': fields.String,
  'payload': fields.Raw,
  'status': fields.String,
  'created_at': fields.DateTime,
  'updated_at': fields.DateTime,
  'assignments': fields.List(fields.Nested(assignment_model))
})
case_create_model = api.model('CaseCreate', {
    'type': fields.String(required=True, description='Type: transaction or wallet'),
    'reference_id': fields.String(required=True, description='Reference ID (tx_hash or address)')
})
case_update_model = api.model('CaseUpdate', {
    'description': fields.String,
    'status': fields.String,
    'reason': fields.String,
    'source': fields.String,
    'tags': fields.List(fields.String)
})

# GET /api/cases?limit=...
@api.route('')
class CaseList(Resource):
    @api.marshal_list_with(case_model)
    @login_required
    @roles_required('admin')
    def get(self):
        limit = request.args.get('limit', default=50, type=int)
        user_id = g.user_id
        user_role = g.role

        all_cases = list_cases(limit)
        if user_role == 'admin':
            return all_cases

        visible_cases = []
        for c in all_cases:
            assigned_user_ids = [a['user_id'] for a in c.get('assignments', [])]
            if user_id in assigned_user_ids:
                visible_cases.append(c)
        return visible_cases

    @api.expect(case_create_model)
    # @jwt_roles_required('L1', 'L2', 'admin')
    def post(self):
        """Create a new case from anomaly or blacklist"""
        data = request.json
        case_type = data.get('type')
        reference = data.get('reference_id')

        if case_type not in ['transaction', 'wallet']:
            return {'message': 'Invalid case type'}, 400
        if not reference:
            return {'message': 'Reference is required'}, 400

        try:
            case_id = create_case(case_type, reference)
            return {'message': 'Case created successfully', 'case_id': case_id}, 201
        except Exception as e:
            import traceback; traceback.print_exc()   # <<<
            return {'message': str(e)}, 500

# POST /api/cases/{id}/assign
assign_payload = api.model('AssignPayload', {
    'user_id': fields.Integer(required=True, description='ID pengguna')
})
@api.route('/<int:case_id>/assign')
class CaseAssign(Resource):
    @api.expect(assign_payload)
    # @jwt_roles_required('admin')
    def post(self, case_id):
        """Assign a case to a user (admin only)"""
        user_id = request.get_json().get('user_id')
        assign_case(case_id, user_id)
        return {'status':'assigned'}, 200
    
@api.route('/<int:case_id>')
class CaseDetail(Resource):
    @api.expect(case_update_model)
    # @jwt_roles_required('L1', 'L2', 'admin')
    def patch(self, case_id):
        """Update a case (description, status, reason, etc)"""
        case = get_case_with_assignments(case_id)
        if not case:
            return {'message': 'Case not found'}, 404

        assigned_user_ids = [a['user_id'] for a in case.get('assignments', [])]
        if current_user.role != 'admin' and current_user.id not in assigned_user_ids:
            return {'message': 'You are not allowed to edit this case'}, 403
        
        try:
            update_case(case_id, request.get_json())
            return {'message': 'Case updated successfully'}, 200
        except ValueError as e:
            return {'message': str(e)}, 400
        except Exception as e:
            import traceback; traceback.print_exc()
            return {'message': 'Internal server error'}, 500
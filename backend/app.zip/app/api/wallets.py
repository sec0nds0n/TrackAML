from flask_restx import Namespace, Resource, fields
from flask import request
from ..utils import jwt_required
from ..database import get_db_connection
from ..services.wallet_service import update_all_wallets_logic, sync_database_logic

ns_wallets_api = Namespace('wallets-api', description='Wallet management endpoints')

# Schema untuk wallet history
wallet_model = ns_wallets_api.model('WalletHistory', {
    'address': fields.String(required=True, description='Wallet address'),
    'queried_at': fields.DateTime(required=False, description='Last queried timestamp'),
})

@ns_wallets_api.route('/update-all')
class UpdateAllWallets(Resource):
    # @jwt_required
    def post(self):
        """Fetch & update all wallets from history"""
        success, fail = update_all_wallets_logic()
        return {
            "message": f"Selesai update {success} wallet. Gagal: {fail}",
            "success": success,
            "failed": fail
        }, 200

@ns_wallets_api.route('/sync')
class SyncDatabase(Resource):
    # @jwt_required
    def post(self):
        """Sinkronisasi database ke Neo4j dan update blacklist"""
        success = sync_database_logic()
        if not success:
            return {"message": "Neo4j tidak tersedia, sync gagal."}, 503
        return {"message": "✅ Sinkronisasi database berhasil!"}, 200

@ns_wallets_api.route('/history')
class WalletHistory(Resource):
    @ns_wallets_api.marshal_list_with(wallet_model)
    def get(self):
        """List recent wallet history (limit 10)"""
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT address, queried_at
            FROM wallet_history
            ORDER BY queried_at DESC NULLS LAST
            LIMIT 10
        """)
        rows = cur.fetchall()
        cur.close()
        conn.close()

        return [
            {"address": r[0], "queried_at": r[1] if r[1] else None}
            for r in rows
        ]

@ns_wallets_api.route('/<string:address>/transactions/all')
class WalletTransactions(Resource):
    def get(self, address):
        conn = get_db_connection()
        cur = conn.cursor(cursor_factory=RealDictCursor)
        cur.execute("""
            SELECT sender, receiver, value, timestamp
            FROM transactions
            WHERE sender = %s OR receiver = %s
            ORDER BY timestamp DESC
            LIMIT 100
        """, (address, address))
        rows = cur.fetchall()
        cur.close()
        conn.close()
        return rows
    
@ns_wallets_api.route('/transactions')
class WalletTransactions(Resource):
    def get(self):
        wallet = request.args.get('wallet')
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))

        if not wallet:
            return [], 400

        offset = (page - 1) * per_page

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT sender, receiver, value, timestamp
            FROM transactions
            WHERE sender = %s OR receiver = %s
            ORDER BY timestamp DESC
            LIMIT %s OFFSET %s
        """, (wallet, wallet, per_page, offset))
        rows = cur.fetchall()

        # Get total count for pagination
        cur.execute("""
            SELECT COUNT(*) FROM transactions
            WHERE sender = %s OR receiver = %s
        """, (wallet, wallet))
        total = cur.fetchone()[0]

        cur.close()
        conn.close()

        return {
            "transactions": [
                {"sender": r[0], "receiver": r[1], "value": r[2], "timestamp": r[3].isoformat()}
                for r in rows
            ],
            "total": total,
            "page": page,
            "per_page": per_page
        }
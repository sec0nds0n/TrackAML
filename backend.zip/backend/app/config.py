from dotenv import load_dotenv
load_dotenv()
import os

class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'change_this')
    SESSION_TYPE = 'filesystem'
    NEO4J_URI = os.getenv('NEO4J_URI')
    NEO4J_USER = os.getenv('NEO4J_USER')
    NEO4J_PASSWORD = os.getenv('NEO4J_PASSWORD')
    ETHERSCAN_API_KEY = os.getenv('ETHERSCAN_API_KEY')